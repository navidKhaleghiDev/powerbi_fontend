import { Suspense } from "react";

import { AccessManagementPage } from "@/components/pages/DataPlatform/AccessManagement";
import { Skeleton } from "@uiShare/molecules/Loading/LoadingSkeleton";

export default function DataPlatformAccessPage() {
  return (
    <Suspense fallback={<Skeleton className="h-64" />}>
      <AccessManagementPage />
    </Suspense>
  );
}

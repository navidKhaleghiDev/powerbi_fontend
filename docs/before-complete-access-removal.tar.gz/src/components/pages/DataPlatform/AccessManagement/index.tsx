"use client";

import { useState } from "react";

import { useTranslations } from "next-intl";

import { useNavigate } from "@/hooks/useNavigate";
import { RouteName } from "@/routes/routesConstants";

/* ---------------------------------------------------------------------------
 * Mock access data — represents the centralized access management panel
 * ------------------------------------------------------------------------- */

interface UserAccess {
  username: string;
  displayName: string;
  adGroups: string[];
  ssasRoles: string[];
  rlsDimensions: { dimension: string; allowedValues: string[] }[];
  directReports: string[];
}

const mockUsers: UserAccess[] = [
  {
    username: "ahmadi",
    displayName: "Mohammad Ahmadi",
    adGroups: ["Finance-Team", "PowerBI-Viewers"],
    ssasRoles: ["FinanceReader", "SalesReader"],
    rlsDimensions: [
      { dimension: "Factory", allowedValues: ["Tehran", "Isfahan"] },
      { dimension: "CostCenter", allowedValues: ["CC-101", "CC-102"] },
    ],
    directReports: ["Monthly Sales Report", "Finance Dashboard"],
  },
  {
    username: "rezaii",
    displayName: "Ali Rezaei",
    adGroups: ["Sales-Managers", "PowerBI-Designers"],
    ssasRoles: ["SalesManager", "SalesReader"],
    rlsDimensions: [
      { dimension: "Branch", allowedValues: ["North", "South"] },
    ],
    directReports: ["Sales Pipeline", "Customer Analysis"],
  },
];

/* ---------------------------------------------------------------------------
 * User access detail panel
 * ------------------------------------------------------------------------- */

interface AccessDetailProps {
  user: UserAccess;
}

const AccessDetail = ({ user }: AccessDetailProps) => {
  const t = useTranslations("dataPlatform");

  return (
    <div className="space-y-4">
      {/* AD Groups */}
      <div className="rounded-xl border border-gray-200 p-4 dark:border-gray-800">
        <h3 className="mb-2 text-sm font-semibold text-gray-900 dark:text-white">
          {t("accessManagement.adGroups")}
        </h3>
        <div className="flex flex-wrap gap-2">
          {user.adGroups.map((group) => (
            <span
              key={group}
              className="rounded-lg bg-blue-50 px-3 py-1 text-xs font-medium text-blue-700 dark:bg-blue-950/40 dark:text-blue-400"
            >
              {group}
            </span>
          ))}
        </div>
      </div>

      {/* SSAS Roles */}
      <div className="rounded-xl border border-gray-200 p-4 dark:border-gray-800">
        <h3 className="mb-2 text-sm font-semibold text-gray-900 dark:text-white">
          {t("accessManagement.ssasRoles")}
        </h3>
        <div className="flex flex-wrap gap-2">
          {user.ssasRoles.map((role) => (
            <span
              key={role}
              className="rounded-lg bg-violet-50 px-3 py-1 text-xs font-medium text-violet-700 dark:bg-violet-950/40 dark:text-violet-400"
            >
              {role}
            </span>
          ))}
        </div>
      </div>

      {/* RLS Dimensions */}
      <div className="rounded-xl border border-gray-200 p-4 dark:border-gray-800">
        <h3 className="mb-2 text-sm font-semibold text-gray-900 dark:text-white">
          {t("accessManagement.dynamicRls")}
        </h3>
        <div className="space-y-2">
          {user.rlsDimensions.map((dim) => (
            <div key={dim.dimension}>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {dim.dimension}
              </p>
              <div className="mt-1 flex flex-wrap gap-1">
                {dim.allowedValues.map((val) => (
                  <span
                    key={val}
                    className="rounded bg-emerald-50 px-2 py-0.5 text-xs text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400"
                  >
                    {val}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Direct Report Access */}
      <div className="rounded-xl border border-gray-200 p-4 dark:border-gray-800">
        <h3 className="mb-2 text-sm font-semibold text-gray-900 dark:text-white">
          {t("accessManagement.pbrsPermissions")}
          <span className="ms-2 text-xs font-normal text-gray-400">
            ({t("accessManagement.directAccess")})
          </span>
        </h3>
        <div className="space-y-1">
          {user.directReports.map((report) => (
            <div
              key={report}
              className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300"
            >
              <span className="size-1.5 rounded-full bg-blue-500" />
              {report}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

/* ---------------------------------------------------------------------------
 * Main access management page
 * ------------------------------------------------------------------------- */

export const AccessManagementPage = () => {
  const t = useTranslations("dataPlatform");
  const router = useNavigate();
  const [selectedUser, setSelectedUser] = useState<UserAccess | null>(null);

  return (
    <div className="space-y-6 p-4 lg:p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            {t("accessManagement.title")}
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            {t("accessManagement.description")}
          </p>
        </div>
        <button
          onClick={() => router.push(RouteName.data_platform.path)}
          className="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400"
        >
          {t("nav.dashboard")}
        </button>
      </div>

      {/* Feature cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          "copyAccess",
          "batchProvisioning",
          "dynamicRls",
          "effectiveAccess",
        ].map((feature) => (
          <div
            key={feature}
            className="rounded-2xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900"
          >
            <p className="text-sm font-medium text-gray-900 dark:text-white">
              {t(`accessManagement.${feature}`)}
            </p>
          </div>
        ))}
      </div>

      {/* Effective access viewer */}
      <section>
        <h2 className="mb-3 text-lg font-semibold text-gray-900 dark:text-white">
          {t("accessManagement.effectiveAccess")}
        </h2>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          {/* User selector */}
          <div className="lg:col-span-1">
            <div className="space-y-2">
              {mockUsers.map((user) => (
                <button
                  key={user.username}
                  onClick={() => setSelectedUser(user)}
                  className={`w-full rounded-xl border p-3 text-start transition-colors ${
                    selectedUser?.username === user.username
                      ? "border-blue-400 bg-blue-50 dark:border-blue-700 dark:bg-blue-950/30"
                      : "border-gray-200 hover:border-blue-300 dark:border-gray-800 dark:hover:border-blue-700"
                  }`}
                >
                  <p className="font-medium text-gray-900 dark:text-white">
                    {user.displayName}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {user.username}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Access detail */}
          <div className="lg:col-span-2">
            {selectedUser ? (
              <AccessDetail user={selectedUser} />
            ) : (
              <div className="flex h-full items-center justify-center rounded-xl border border-dashed border-gray-200 p-12 dark:border-gray-700">
                <p className="text-sm text-gray-400">
                  {t("accessManagement.selectUser")}
                </p>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

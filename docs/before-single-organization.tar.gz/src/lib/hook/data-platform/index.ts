/**
 * TanStack Query hooks for the Data Platform Control Center.
 *
 * These follow the project's established hook pattern (see
 * `src/lib/hook/dashboard/index.ts` for the reference implementation): each
 * query has a string key, an async fetcher, and staleTime: 0.
 *
 * The fetchers call `dataPlatformApi` which currently returns mock data.  When
 * a real backend is available, replace the fetcher bodies with `http.get(...)`
 * calls — the hook signatures and query keys stay the same.
 */

import { useQuery } from "@tanstack/react-query";

import { dataPlatformApi } from "@/lib/data-platform/mockData";

/* ---------------------------------------------------------------------------
 * Query keys
 * ------------------------------------------------------------------------- */

export const DP_ORGANIZATIONS_KEY = "data-platform/organizations";
export const DP_CONNECTIONS_KEY = "data-platform/connections";
export const DP_DATASETS_KEY = "data-platform/datasets";
export const DP_SCHEMA_VERSIONS_KEY = "data-platform/schema-versions";
export const DP_SYNC_POLICIES_KEY = "data-platform/sync-policies";
export const DP_SYNC_RUNS_KEY = "data-platform/sync-runs";
export const DP_INGESTION_BATCHES_KEY = "data-platform/ingestion-batches";
export const DP_CHECKPOINTS_KEY = "data-platform/checkpoints";
export const DP_QUALITY_RESULTS_KEY = "data-platform/quality-results";
export const DP_WAREHOUSE_RECORDS_KEY = "data-platform/warehouse-records";
export const DP_OBSERVABILITY_KEY = "data-platform/observability";
export const DP_SCENARIO_RESULTS_KEY = "data-platform/scenario-results";

/* ---------------------------------------------------------------------------
 * Hooks
 * ------------------------------------------------------------------------- */

export const useGetOrganizations = () =>
  useQuery({
    queryKey: [DP_ORGANIZATIONS_KEY],
    queryFn: () => dataPlatformApi.getOrganizations(),
    staleTime: 0,
  });

export const useGetConnections = () =>
  useQuery({
    queryKey: [DP_CONNECTIONS_KEY],
    queryFn: () => dataPlatformApi.getConnections(),
    staleTime: 0,
  });

export const useGetDatasets = () =>
  useQuery({
    queryKey: [DP_DATASETS_KEY],
    queryFn: () => dataPlatformApi.getDatasets(),
    staleTime: 0,
  });

export const useGetSchemaVersions = () =>
  useQuery({
    queryKey: [DP_SCHEMA_VERSIONS_KEY],
    queryFn: () => dataPlatformApi.getSchemaVersions(),
    staleTime: 0,
  });

export const useGetSyncPolicies = () =>
  useQuery({
    queryKey: [DP_SYNC_POLICIES_KEY],
    queryFn: () => dataPlatformApi.getSyncPolicies(),
    staleTime: 0,
  });

export const useGetSyncRuns = () =>
  useQuery({
    queryKey: [DP_SYNC_RUNS_KEY],
    queryFn: () => dataPlatformApi.getSyncRuns(),
    staleTime: 0,
  });

export const useGetIngestionBatches = () =>
  useQuery({
    queryKey: [DP_INGESTION_BATCHES_KEY],
    queryFn: () => dataPlatformApi.getIngestionBatches(),
    staleTime: 0,
  });

export const useGetCheckpoints = () =>
  useQuery({
    queryKey: [DP_CHECKPOINTS_KEY],
    queryFn: () => dataPlatformApi.getCheckpoints(),
    staleTime: 0,
  });

export const useGetQualityResults = () =>
  useQuery({
    queryKey: [DP_QUALITY_RESULTS_KEY],
    queryFn: () => dataPlatformApi.getQualityResults(),
    staleTime: 0,
  });

export const useGetWarehouseRecords = () =>
  useQuery({
    queryKey: [DP_WAREHOUSE_RECORDS_KEY],
    queryFn: () => dataPlatformApi.getWarehouseRecords(),
    staleTime: 0,
  });

export const useGetObservabilityMetrics = () =>
  useQuery({
    queryKey: [DP_OBSERVABILITY_KEY],
    queryFn: () => dataPlatformApi.getObservabilityMetrics(),
    staleTime: 0,
  });

export const useGetScenarioResults = () =>
  useQuery({
    queryKey: [DP_SCENARIO_RESULTS_KEY],
    queryFn: () => dataPlatformApi.getScenarioResults(),
    staleTime: 0,
  });

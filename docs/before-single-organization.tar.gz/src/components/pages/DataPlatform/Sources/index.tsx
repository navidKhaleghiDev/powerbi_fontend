"use client";

import { useTranslations } from "next-intl";

import { useNavigate } from "@/hooks/useNavigate";
import {
  useGetConnections,
  useGetDatasets,
  useGetOrganizations,
  useGetSyncPolicies,
} from "@/lib/hook/data-platform";
import type {
  Connection,
  Dataset,
  Organization,
  SyncMode,
  SyncPolicy,
} from "@/lib/data-platform";
import { RouteName } from "@/routes/routesConstants";
import { LoadingSkelton } from "@uiShare/molecules/Loading/LoadingSkeleton";

/* ---------------------------------------------------------------------------
 * Sync mode badge colors
 * ------------------------------------------------------------------------- */

const modeColors: Record<SyncMode, string> = {
  "log-cdc": "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400",
  "incremental-polling":
    "bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400",
  "full-snapshot":
    "bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400",
};

const residencyColors: Record<string, string> = {
  "cloud-first": "bg-sky-50 text-sky-700 dark:bg-sky-950/40 dark:text-sky-400",
  "hybrid-restricted":
    "bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400",
  "fully-onprem":
    "bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400",
};

/* ---------------------------------------------------------------------------
 * Organization card
 * ------------------------------------------------------------------------- */

interface OrgCardProps {
  org: Organization;
  connections: Connection[];
  datasets: Dataset[];
  policies: SyncPolicy[];
}

const OrgCard = ({ org, connections, datasets, policies }: OrgCardProps) => {
  const t = useTranslations("dataPlatform");

  const orgConnections = connections.filter(
    (c) => c.organizationId === org.organizationId,
  );
  const orgDatasetIds = datasets
    .filter((d) => orgConnections.some((c) => c.connectionId === d.sourceId))
    .map((d) => d.datasetId);
  const orgPolicies = policies.filter((p) =>
    orgDatasetIds.includes(p.datasetId),
  );

  return (
    <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-gray-900">
      <div className="flex items-center justify-between">
        <h3 className="text-base font-semibold text-gray-900 dark:text-white">
          {org.name}
        </h3>
        <span
          className={`rounded-full px-3 py-1 text-xs font-medium ${residencyColors[org.residencyPolicy]}`}
        >
          {t(`sources.residencyPolicies.${org.residencyPolicy}`)}
        </span>
      </div>
      <div className="mt-4 grid grid-cols-3 gap-3">
        <div className="rounded-xl bg-gray-50 p-3 dark:bg-gray-800/50">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            {t("sources.connection")}
          </p>
          <p className="mt-1 text-lg font-bold text-gray-900 dark:text-white">
            {orgConnections.length}
          </p>
        </div>
        <div className="rounded-xl bg-gray-50 p-3 dark:bg-gray-800/50">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            {t("sources.dataset")}
          </p>
          <p className="mt-1 text-lg font-bold text-gray-900 dark:text-white">
            {orgDatasetIds.length}
          </p>
        </div>
        <div className="rounded-xl bg-gray-50 p-3 dark:bg-gray-800/50">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            {t("sources.syncMode")}
          </p>
          <p className="mt-1 text-lg font-bold text-gray-900 dark:text-white">
            {orgPolicies.length}
          </p>
        </div>
      </div>

      {/* Connections list */}
      <div className="mt-4 space-y-2">
        {orgConnections.map((conn) => {
          const connDatasets = datasets.filter(
            (d) => d.sourceId === conn.connectionId,
          );
          return (
            <div
              key={conn.connectionId}
              className="flex items-center justify-between rounded-lg border border-gray-100 px-3 py-2 dark:border-gray-800"
            >
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {conn.engineType}
                </span>
                {conn.agentId ? (
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    {t("sources.agent")}: {conn.agentId}
                  </span>
                ) : (
                  <span className="text-xs text-gray-400 dark:text-gray-500">
                    {t("sources.noAgent")}
                  </span>
                )}
              </div>
              <span className="text-xs text-gray-500 dark:text-gray-400">
                {t("sources.datasetsCount", { count: connDatasets.length })}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* ---------------------------------------------------------------------------
 * Sync policies table
 * ------------------------------------------------------------------------- */

const PoliciesTable = () => {
  const t = useTranslations("dataPlatform");
  const { data: policies, isLoading } = useGetSyncPolicies();
  const { data: datasets } = useGetDatasets();

  if (isLoading || !policies || !datasets) {
    return <LoadingSkelton isLoading className="h-64" />;
  }

  return (
    <div className="overflow-x-auto rounded-2xl border border-gray-200 dark:border-gray-800">
      <table className="w-full text-sm">
        <thead className="bg-gray-50 dark:bg-gray-800/50">
          <tr>
            <th className="px-4 py-3 text-start font-medium text-gray-600 dark:text-gray-400">
              {t("sources.dataset")}
            </th>
            <th className="px-4 py-3 text-start font-medium text-gray-600 dark:text-gray-400">
              {t("sources.syncMode")}
            </th>
            <th className="px-4 py-3 text-start font-medium text-gray-600 dark:text-gray-400">
              {t("sources.schedule")}
            </th>
            <th className="px-4 py-3 text-start font-medium text-gray-600 dark:text-gray-400">
              {t("sources.deleteStrategy")}
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
          {policies.map((policy) => {
            const dataset = datasets.find((d) => d.datasetId === policy.datasetId);
            return (
              <tr key={policy.policyId}>
                <td className="px-4 py-3 text-gray-900 dark:text-gray-200">
                  {dataset?.sourceLocator ?? policy.datasetId}
                </td>
                <td className="px-4 py-3">
                  <span
                    className={`rounded-full px-2 py-1 text-xs font-medium ${modeColors[policy.mode]}`}
                  >
                    {t(`sources.syncModes.${policy.mode}`)}
                  </span>
                </td>
                <td className="px-4 py-3 font-mono text-xs text-gray-600 dark:text-gray-400">
                  {policy.schedule}
                </td>
                <td className="px-4 py-3 text-gray-600 dark:text-gray-400">
                  {policy.deleteStrategy}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

/* ---------------------------------------------------------------------------
 * Main sources page
 * ------------------------------------------------------------------------- */

export const DataPlatformSources = () => {
  const t = useTranslations("dataPlatform");
  const router = useNavigate();

  const { data: orgs, isLoading: orgsLoading } = useGetOrganizations();
  const { data: connections } = useGetConnections();
  const { data: datasets } = useGetDatasets();
  const { data: policies } = useGetSyncPolicies();

  return (
    <div className="space-y-6 p-4 lg:p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            {t("sources.title")}
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            {t("sources.description")}
          </p>
        </div>
        <button
          onClick={() => router.push(RouteName.data_platform.path)}
          className="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400"
        >
          {t("nav.dashboard")}
        </button>
      </div>

      {/* Organization cards */}
      {orgsLoading || !orgs || !connections || !datasets || !policies ? (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <LoadingSkelton isLoading className="h-64" />
          <LoadingSkelton isLoading className="h-64" />
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {orgs.map((org) => (
            <OrgCard
              key={org.organizationId}
              org={org}
              connections={connections}
              datasets={datasets}
              policies={policies}
            />
          ))}
        </div>
      )}

      {/* Sync policies table */}
      <section>
        <h2 className="mb-3 text-lg font-semibold text-gray-900 dark:text-white">
          {t("sources.syncMode")}
        </h2>
        <PoliciesTable />
      </section>
    </div>
  );
};

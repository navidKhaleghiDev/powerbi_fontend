"use client";

import { useTranslations } from "next-intl";

import { useGetConnections, useGetOrganizations } from "@/lib/hook/data-platform";
import type { ResidencyPolicy } from "@/lib/data-platform";

/* ---------------------------------------------------------------------------
 * Region data — each region has a position on the SVG canvas and a list of
 * organizations/sources that live there.
 * ------------------------------------------------------------------------- */

interface RegionNode {
  id: string;
  labelKey: string;
  x: number;
  y: number;
  sources: { orgName: string; policy: ResidencyPolicy; engineType: string }[];
}

const useRegionData = (): RegionNode[] => {
  const { data: orgs } = useGetOrganizations();
  const { data: connections } = useGetConnections();

  if (!orgs || !connections) return [];

  // Map organizations to regions based on residency policy
  const regionMap: Record<string, RegionNode> = {
    "us-east": {
      id: "us-east",
      labelKey: "gis.regions.us-east",
      x: 200,
      y: 160,
      sources: [],
    },
    "eu-west": {
      id: "eu-west",
      labelKey: "gis.regions.eu-west",
      x: 380,
      y: 120,
      sources: [],
    },
    "me-central": {
      id: "me-central",
      labelKey: "gis.regions.me-central",
      x: 460,
      y: 180,
      sources: [],
    },
    "ap-south": {
      id: "ap-south",
      labelKey: "gis.regions.ap-south",
      x: 600,
      y: 260,
      sources: [],
    },
  };

  const policyToRegion: Record<ResidencyPolicy, string> = {
    "cloud-first": "us-east",
    "hybrid-restricted": "eu-west",
    "fully-onprem": "me-central",
  };

  for (const org of orgs) {
    const regionId = policyToRegion[org.residencyPolicy] ?? "us-east";
    const orgConns = connections.filter(
      (c) => c.organizationId === org.organizationId,
    );
    for (const conn of orgConns) {
      regionMap[regionId]?.sources.push({
        orgName: org.name,
        policy: org.residencyPolicy,
        engineType: conn.engineType,
      });
    }
  }

  return Object.values(regionMap);
};

/* ---------------------------------------------------------------------------
 * SVG map component
 * ------------------------------------------------------------------------- */

const policyColors: Record<ResidencyPolicy, string> = {
  "cloud-first": "#3b82f6",
  "hybrid-restricted": "#f59e0b",
  "fully-onprem": "#ef4444",
};

const GisMap = () => {
  const t = useTranslations("dataPlatform");
  const regions = useRegionData();

  return (
    <div className="rounded-2xl border border-gray-200 p-5 dark:border-gray-800">
      <h3 className="mb-1 text-sm font-semibold text-gray-900 dark:text-white">
        {t("gis.title")}
      </h3>
      <p className="mb-4 text-xs text-gray-500 dark:text-gray-400">
        {t("gis.description")}
      </p>

      <div className="relative overflow-x-auto">
        <svg
          viewBox="0 0 750 350"
          className="w-full min-w-[600px]"
          style={{ maxHeight: "400px" }}
        >
          {/* Simple world map outline (abstract regions) */}
          <rect
            x="0"
            y="0"
            width="750"
            height="350"
            className="fill-gray-50 dark:fill-gray-900"
            rx="12"
          />

          {/* Region connection lines (data flow) */}
          {regions.length > 1 &&
            regions.slice(0, -1).map((region, idx) => {
              const next = regions[idx + 1];
              return (
                <line
                  key={`flow-${region.id}`}
                  x1={region.x}
                  y1={region.y}
                  x2={next.x}
                  y2={next.y}
                  className="stroke-gray-300 dark:stroke-gray-700"
                  strokeWidth="1.5"
                  strokeDasharray="6 4"
                />
            );
            })}

          {/* Region nodes */}
          {regions.map((region) => (
            <g key={region.id}>
              {/* Outer glow circle */}
              <circle
                cx={region.x}
                cy={region.y}
                r={region.sources.length > 0 ? 28 : 20}
                className="fill-blue-50 dark:fill-blue-950/40"
                opacity={0.5}
              />
              {/* Main node circle */}
              <circle
                cx={region.x}
                cy={region.y}
                r={16}
                className={
                  region.sources.length > 0
                    ? "fill-blue-500 dark:fill-blue-400"
                    : "fill-gray-300 dark:fill-gray-700"
                }
              />
              {/* Source count */}
              {region.sources.length > 0 && (
                <text
                  x={region.x}
                  y={region.y + 4}
                  textAnchor="middle"
                  className="fill-white text-xs font-bold"
                >
                  {region.sources.length}
                </text>
              )}
              {/* Region label */}
              <text
                x={region.x}
                y={region.y + 40}
                textAnchor="middle"
                className="fill-gray-700 dark:fill-gray-300 text-xs font-medium"
              >
                {t(region.labelKey)}
              </text>
            </g>
          ))}
        </svg>
      </div>

      {/* Legend */}
      <div className="mt-4 flex flex-wrap gap-4">
        <div className="flex items-center gap-2">
          <div className="size-3 rounded-full bg-blue-500" />
          <span className="text-xs text-gray-600 dark:text-gray-400">
            {t("gis.legend.cloud")}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <div className="size-3 rounded-full bg-amber-500" />
          <span className="text-xs text-gray-600 dark:text-gray-400">
            {t("gis.legend.onprem")}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-6 border-t-2 border-dashed border-gray-400" />
          <span className="text-xs text-gray-600 dark:text-gray-400">
            {t("gis.legend.flow")}
          </span>
        </div>
      </div>

      {/* Source detail list */}
      <div className="mt-4 space-y-2">
        {regions
          .filter((r) => r.sources.length > 0)
          .map((region) =>
            region.sources.map((source, idx) => (
              <div
                key={`${region.id}-${idx}`}
                className="flex items-center justify-between rounded-lg border border-gray-100 px-3 py-2 dark:border-gray-800"
              >
                <div className="flex items-center gap-2">
                  <div
                    className="size-2.5 rounded-full"
                    style={{ backgroundColor: policyColors[source.policy] }}
                  />
                  <span className="text-sm text-gray-700 dark:text-gray-300">
                    {source.orgName}
                  </span>
                  <span className="text-xs text-gray-400">
                    {source.engineType}
                  </span>
                </div>
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  {source.policy === "cloud-first"
                    ? t("gis.cloudFirst")
                    : source.policy === "hybrid-restricted"
                      ? t("gis.hybridRestricted")
                      : t("gis.fullyOnprem")}
                </span>
              </div>
            )),
          )}
      </div>
    </div>
  );
};

export { GisMap };

/* ---------------------------------------------------------------------------
 * GIS Analytics panel — shows summary statistics and a regional breakdown
 * bar chart alongside the geographic map.
 * ------------------------------------------------------------------------- */

const RegionAnalytics = () => {
  const t = useTranslations("dataPlatform");
  const regions = useRegionData();

  const totalSources = regions.reduce((sum, r) => sum + r.sources.length, 0);
  const cloudSources = regions.reduce(
    (sum, r) =>
      sum + r.sources.filter((s) => s.policy === "cloud-first").length,
    0,
  );
  const onpremSources = totalSources - cloudSources;
  const maxSources = Math.max(...regions.map((r) => r.sources.length), 1);

  const summaryStats = [
    { label: t("gis.analytics.totalSources"), value: totalSources, color: "text-blue-600 dark:text-blue-400" },
    { label: t("gis.analytics.cloudSources"), value: cloudSources, color: "text-emerald-600 dark:text-emerald-400" },
    { label: t("gis.analytics.onpremSources"), value: onpremSources, color: "text-amber-600 dark:text-amber-400" },
  ];

  return (
    <div className="space-y-4">
      {/* Summary stats */}
      <div className="grid grid-cols-3 gap-3">
        {summaryStats.map((stat) => (
          <div
            key={stat.label}
            className="rounded-xl border border-gray-200 p-3 text-center dark:border-gray-800"
          >
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {stat.label}
            </p>
            <p className={`mt-1 text-2xl font-bold ${stat.color}`}>
              {stat.value}
            </p>
          </div>
        ))}
      </div>

      {/* Region throughput bar chart */}
      <div className="rounded-xl border border-gray-200 p-4 dark:border-gray-800">
        <p className="mb-3 text-sm font-medium text-gray-700 dark:text-gray-300">
          {t("gis.analytics.throughputByRegion")}
        </p>
        <div className="space-y-2">
          {regions.map((region) => {
            const percentage = (region.sources.length / maxSources) * 100;
            return (
              <div key={region.id} className="flex items-center gap-3">
                <span className="w-24 shrink-0 text-xs text-gray-600 dark:text-gray-400">
                  {t(region.labelKey)}
                </span>
                <div className="h-6 flex-1 overflow-hidden rounded-lg bg-gray-100 dark:bg-gray-800">
                  <div
                    className="flex h-full items-center justify-end rounded-lg bg-gradient-to-l from-blue-500 to-indigo-500 px-2 text-xs font-medium text-white transition-all duration-500"
                    style={{ width: `${Math.max(percentage, 8)}%` }}
                  >
                    {region.sources.length > 0 && (
                      <span>{region.sources.length}</span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Residency distribution */}
      <div className="rounded-xl border border-gray-200 p-4 dark:border-gray-800">
        <p className="mb-3 text-sm font-medium text-gray-700 dark:text-gray-300">
          {t("gis.analytics.residencyDistribution")}
        </p>
        <div className="flex h-4 w-full overflow-hidden rounded-full bg-gray-100 dark:bg-gray-800">
          {totalSources > 0 && (
            <>
              <div
                className="bg-blue-500"
                style={{ width: `${(cloudSources / totalSources) * 100}%` }}
                title={t("gis.analytics.cloudSources")}
              />
              <div
                className="bg-amber-500"
                style={{ width: `${(onpremSources / totalSources) * 100}%` }}
                title={t("gis.analytics.onpremSources")}
              />
            </>
          )}
        </div>
        <div className="mt-2 flex justify-between text-xs">
          <span className="text-blue-600 dark:text-blue-400">
            {t("gis.analytics.cloudSources")}: {cloudSources}
          </span>
          <span className="text-amber-600 dark:text-amber-400">
            {t("gis.analytics.onpremSources")}: {onpremSources}
          </span>
        </div>
      </div>
    </div>
  );
};

/* ---------------------------------------------------------------------------
 * Full GIS section with map + analytics
 * ------------------------------------------------------------------------- */

export const GisMapWithAnalytics = () => {
  const t = useTranslations("dataPlatform");

  return (
    <section className="space-y-4">
      <h2 className="mb-3 text-lg font-semibold text-gray-900 dark:text-white">
        {t("gis.title")}
      </h2>
      <p className="text-sm text-gray-500 dark:text-gray-400">
        {t("gis.description")}
      </p>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <GisMap />
        <div>
          <h3 className="mb-3 text-sm font-semibold text-gray-900 dark:text-white">
            {t("gis.analytics.title")}
          </h3>
          <RegionAnalytics />
        </div>
      </div>
    </section>
  );
};

"use client";

import { useCallback, useMemo } from "react";

import { useParams, useRouter } from "next/navigation";

type RouterType = ReturnType<typeof useRouter>;
type NavigateOptions = NonNullable<Parameters<RouterType["push"]>[1]> & {
  target?: "_self" | "_blank";
};
type PrefetchOptions = Parameters<RouterType["prefetch"]>[1];

type QueryValue = string | number | boolean | (string | number | boolean)[];

export type UrlObject = {
  pathname: string;
  query?: Record<string, QueryValue>;
};

function buildHref(url: string | UrlObject): string {
  if (typeof url === "string") return url;

  const { pathname, query } = url;

  if (!query || Object.keys(query).length === 0) {
    return pathname;
  }

  const params = new URLSearchParams();

  Object.entries(query).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      value.forEach((v) => params.append(key, String(v)));
    } else {
      params.set(key, String(value));
    }
  });

  return `${pathname}?${params.toString()}`;
}

/**
 * Stable application navigation with a consistent URL-object API.
 *
 * Route feedback belongs to the single top progress bar in the locale layout,
 * while destination screens render their own shape-matched skeletons. A second
 * full-screen logo overlay here caused the dashboard to render underneath one
 * or more blocking loaders after login and refresh.
 *
 * Returns stable push, replace, back, forward, refresh, and prefetch methods.
 * Navigation is immediate and does not add a loading overlay.
 */
export const useNavigate = () => {
  const router = useRouter();
  const { locale } = useParams<{ locale: string }>();
  const localHref = useCallback(
    (url: string | UrlObject) => {
      const href = buildHref(url);
      return href.startsWith("/data-platform") ? `/${locale}${href}` : href;
    },
    [locale],
  );

  const push = useCallback(
    (url: string | UrlObject, options?: NavigateOptions) => {
      const { target, ...routerOptions } = options ?? {};
      if (target === "_blank") {
        window.open(localHref(url), "_blank");
        return;
      }
      router.push(localHref(url), routerOptions);
    },
    [router, localHref],
  );

  const replace = useCallback(
    (url: string | UrlObject, options?: NavigateOptions) => {
      router.replace(localHref(url), options);
    },
    [router, localHref],
  );

  const back = useCallback(() => router.back(), [router]);
  const forward = useCallback(() => router.forward(), [router]);

  const refresh = useCallback(() => {
    router.refresh();
  }, [router]);

  const prefetch = useCallback(
    (url: string | UrlObject, options?: PrefetchOptions) => {
      router.prefetch(localHref(url), options);
    },
    [router, localHref],
  );

  return useMemo(
    () => ({ push, replace, back, forward, refresh, prefetch }),
    [push, replace, back, forward, refresh, prefetch],
  );
};

"use client";

import { useState } from "react";

import { useQuery } from "@tanstack/react-query";
import { useLocale, useTranslations } from "next-intl";

import { dataPlatformApi } from "@/lib/data-platform/mockData";
import type { ObservabilityMetrics } from "@/lib/data-platform";
import { useGetIngestionBatches } from "@/lib/hook/data-platform";

/* ---------------------------------------------------------------------------
 * Real-time metrics hook with polling interval
 *
 * Uses TanStack Query's refetchInterval to poll the backend every few seconds,
 * simulating real-time updates.  When paused, the interval is cleared.
 * ------------------------------------------------------------------------- */

const REFRESH_INTERVAL_MS = 5000;

export const useRealtimeMetrics = (enabled: boolean) =>
  useQuery({
    queryKey: ["data-platform/realtime-metrics"],
    queryFn: () => dataPlatformApi.getObservabilityMetrics(),
    refetchInterval: enabled ? REFRESH_INTERVAL_MS : false,
    refetchIntervalInBackground: true,
    staleTime: 0,
  });

/* ---------------------------------------------------------------------------
 * Real-time gauge
 * ------------------------------------------------------------------------- */

interface GaugeProps {
  label: string;
  value: string;
  max: number;
  current: number;
  unit?: string;
}

const Gauge = ({ label, value, max, current, unit }: GaugeProps) => {
  const percentage = Math.min((current / max) * 100, 100);
  const barColor =
    percentage > 80
      ? "bg-red-500"
      : percentage > 50
        ? "bg-amber-500"
        : "bg-emerald-500";

  return (
    <div className="rounded-xl border border-gray-200 p-4 dark:border-gray-800">
      <p className="text-xs text-gray-500 dark:text-gray-400">{label}</p>
      <p className="mt-1 text-xl font-bold text-gray-900 dark:text-white">
        {value}
        {unit && <span className="ms-1 text-sm text-gray-400">{unit}</span>}
      </p>
      <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-gray-100 dark:bg-gray-800">
        <div
          className={`h-full rounded-full transition-all duration-500 ${barColor}`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
};

/* ---------------------------------------------------------------------------
 * Real-time monitor section
 * ------------------------------------------------------------------------- */

export const RealTimeMonitor = () => {
  const t = useTranslations("dataPlatform");
  const [isLive, setIsLive] = useState(true);
  const locale = useLocale();
  const { data: metrics, dataUpdatedAt } = useRealtimeMetrics(isLive);
  const { data: batches } = useGetIngestionBatches();

  const activeBatches = (batches ?? []).filter(
    (b) => b.status === "extracted" || b.status === "uploaded" || b.status === "verified",
  ).length;

  const m = (metrics ?? {}) as Partial<ObservabilityMetrics>;
  const updatedTime = dataUpdatedAt
    ? new Intl.DateTimeFormat(locale, {
        timeStyle: "medium",
        timeZone: "Asia/Tehran",
      }).format(dataUpdatedAt)
    : null;

  return (
    <div className="rounded-2xl border border-gray-200 p-5 dark:border-gray-800">
      {/* Header with live toggle */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h3 className="text-sm font-semibold text-gray-900 dark:text-white">
            {t("realtime.title")}
          </h3>
          {isLive && (
            <span className="flex items-center gap-1 rounded-full bg-red-50 px-2 py-0.5 text-xs font-bold text-red-600 dark:bg-red-950/40 dark:text-red-400">
              <span className="size-1.5 animate-pulse rounded-full bg-red-500" />
              {t("realtime.live")}
            </span>
          )}
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs text-gray-400">
            {updatedTime ? t("realtime.lastUpdated", { time: updatedTime }) : t("loading")}
          </span>
          <button
            onClick={() => setIsLive((prev) => !prev)}
            className={`rounded-lg px-3 py-1 text-xs font-medium transition-colors ${
              isLive
                ? "bg-red-50 text-red-600 hover:bg-red-100 dark:bg-red-950/40 dark:text-red-400"
                : "bg-emerald-50 text-emerald-600 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:text-emerald-400"
            }`}
          >
            {isLive ? t("realtime.pause") : t("realtime.resume")}
          </button>
        </div>
      </div>

      {/* Gauges */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <Gauge
          label={t("realtime.currentThroughput")}
          value={String(Math.round(m.throughputRowsPerSecond ?? 0))}
          max={2000}
          current={m.throughputRowsPerSecond ?? 0}
          unit="r/s"
        />
        <Gauge
          label={t("realtime.currentBacklog")}
          value={String(m.syncBacklog ?? 0)}
          max={20}
          current={m.syncBacklog ?? 0}
        />
        <Gauge
          label={t("realtime.activeBatches")}
          value={String(activeBatches)}
          max={10}
          current={activeBatches}
        />
      </div>
    </div>
  );
};

"use client";

import { useState } from "react";

import { useTranslations } from "next-intl";
import { useParams } from "next/navigation";
import DatePicker from "react-multi-date-picker";
import DateObject from "react-date-object";
import persian from "react-date-object/calendars/persian";
import persian_fa from "react-date-object/locales/persian_fa";
import gregorian from "react-date-object/calendars/gregorian";
import gregorian_en from "react-date-object/locales/gregorian_en";

/**
 * Solar (Jalali) calendar filter for the data platform dashboard.
 *
 * Uses `react-multi-date-picker` with the Persian calendar when the locale
 * is "fa", and the Gregorian calendar otherwise.  This is a page-level
 * component — it does not modify any shared atom.
 *
 * The selected date range is emitted to the parent via `onDateRangeChange`.
 */

interface Props {
  onDateRangeChange?: (range: { from: string; to: string } | null) => void;
}

export const SolarCalendarFilter = ({ onDateRangeChange }: Props) => {
  const t = useTranslations("dataPlatform");
  const params = useParams();
  const locale = params.locale as string | undefined;
  const isFa = locale === "fa";

  const [dateObjects, setDateObjects] = useState<DateObject[]>([]);

  const calendar = isFa ? persian : gregorian;
  const localeObj = isFa ? persian_fa : gregorian_en;

  const handleDateChange = (dates: DateObject[]) => {
    setDateObjects(dates);

    if (!dates || dates.length === 0) {
      onDateRangeChange?.(null);
      return;
    }

    const from = dates[0] instanceof DateObject
      ? dates[0].toDate().toISOString()
      : "";
    const to = dates[1] instanceof DateObject
      ? dates[1].toDate().toISOString()
      : from;
    onDateRangeChange?.({ from, to });
  };

  const handleClear = () => {
    setDateObjects([]);
    onDateRangeChange?.(null);
  };

  return (
    <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-gray-900">
      <h3 className="mb-1 text-sm font-semibold text-gray-900 dark:text-white">
        {t("calendar.title")}
      </h3>
      <p className="mb-4 text-xs text-gray-500 dark:text-gray-400">
        {t("calendar.selectDateRange")}
      </p>

      <div className="flex flex-wrap items-end gap-3">
        {/* Date range picker */}
        <div className="min-w-[200px] flex-1">
          <label className="mb-1 block text-xs text-gray-500 dark:text-gray-400">
            {t("calendar.from")} – {t("calendar.to")}
          </label>
          <DatePicker
            value={dateObjects}
            onChange={handleDateChange}
            range
            calendar={calendar}
            locale={localeObj}
            calendarPosition={isFa ? "bottom-right" : "bottom-left"}
            className="w-full"
            inputClass="w-full rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm text-gray-900 outline-none dark:border-gray-700 dark:bg-gray-800 dark:text-white"
          />
        </div>

        {/* Clear button */}
        <button
          onClick={handleClear}
          className="rounded-xl border border-gray-200 px-4 py-2 text-sm text-gray-600 transition-colors hover:bg-gray-50 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-800"
        >
          {t("calendar.clear")}
        </button>

        {/* Apply button */}
        <button
          onClick={() => handleDateChange(dateObjects)}
          className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600"
        >
          {t("calendar.apply")}
        </button>
      </div>

      {/* Active filter indicator */}
      {dateObjects.length > 0 && (
        <div className="mt-3 flex items-center gap-2 rounded-lg bg-blue-50 px-3 py-2 dark:bg-blue-950/20">
          <span className="size-2 rounded-full bg-blue-500" />
          <span className="text-xs text-blue-700 dark:text-blue-400">
            {t("calendar.filteredData")}
          </span>
        </div>
      )}
    </div>
  );
};

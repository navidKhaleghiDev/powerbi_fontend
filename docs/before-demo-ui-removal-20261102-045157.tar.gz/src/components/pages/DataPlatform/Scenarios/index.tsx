"use client";

import { useState } from "react";

import { useTranslations } from "next-intl";

import { scenarioEngine } from "@/lib/data-platform";
import type { ScenarioId, ScenarioResult } from "@/lib/data-platform";
import { useNavigate } from "@/hooks/useNavigate";
import { RouteName } from "@/routes/routesConstants";
import { LoadingSkelton } from "@uiShare/molecules/Loading/LoadingSkeleton";

/* ---------------------------------------------------------------------------
 * Individual scenario card
 * ------------------------------------------------------------------------- */

interface ScenarioCardProps {
  id: ScenarioId;
  label: string;
  description: string;
  requiredBehavior: string;
  result?: ScenarioResult;
  isRunning: boolean;
  onRun: () => void;
}

const ScenarioCard = ({
  label,
  description,
  requiredBehavior,
  result,
  isRunning,
  onRun,
}: ScenarioCardProps) => {
  const t = useTranslations("dataPlatform");

  return (
    <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-gray-900">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <h3 className="text-base font-semibold text-gray-900 dark:text-white">
            {label}
          </h3>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            {description}
          </p>
        </div>
        <div className="ms-3 flex flex-col items-end gap-2">
          {result && !isRunning && (
            <span
              className={`rounded-full px-3 py-1 text-xs font-bold ${
                result.passed
                  ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400"
                  : "bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400"
              }`}
            >
              {result.passed ? t("scenarios.passed") : t("scenarios.failed")}
            </span>
          )}
        </div>
      </div>

      {/* Required behavior */}
      <div className="mt-3 rounded-lg bg-blue-50/50 p-3 dark:bg-blue-950/20">
        <p className="text-xs text-gray-600 dark:text-gray-400">
          <span className="font-medium">
            {t("scenarios.title")}:{" "}
          </span>
          {requiredBehavior}
        </p>
      </div>

      {/* Run button */}
      <button
        onClick={onRun}
        disabled={isRunning}
        className="mt-4 w-full rounded-xl bg-blue-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-blue-700 disabled:opacity-50 dark:bg-blue-500 dark:hover:bg-blue-600"
      >
        {isRunning ? t("scenarios.running") : t("scenarios.run")}
      </button>

      {/* Results */}
      {result && !isRunning && (
        <div className="mt-4 space-y-3">
          {/* Steps */}
          <div className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
            <p className="mb-2 text-xs font-medium text-gray-600 dark:text-gray-400">
              {t("scenarios.steps")}
            </p>
            <div className="space-y-1">
              {result.steps.map((step, idx) => (
                <div
                  key={idx}
                  className="flex items-start gap-2 text-xs text-gray-600 dark:text-gray-400"
                >
                  <span className="font-mono text-gray-400">{idx + 1}.</span>
                  <span
                    className={
                      step.includes("FAIL")
                        ? "text-red-600 dark:text-red-400"
                        : step.includes("PASS")
                          ? "text-emerald-600 dark:text-emerald-400"
                          : ""
                    }
                  >
                    {step}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Summary */}
          <div className="grid grid-cols-3 gap-2">
            <div className="rounded-lg bg-gray-50 p-2 text-center dark:bg-gray-800/50">
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {t("scenarios.finalStatus")}
              </p>
              <p className="mt-1 text-sm font-medium text-gray-900 dark:text-white">
                {result.finalBatchStatus}
              </p>
            </div>
            <div className="rounded-lg bg-gray-50 p-2 text-center dark:bg-gray-800/50">
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {t("scenarios.finalCursor")}
              </p>
              <p className="mt-1 font-mono text-xs text-gray-900 dark:text-white">
                {result.finalCursor}
              </p>
            </div>
            <div className="rounded-lg bg-gray-50 p-2 text-center dark:bg-gray-800/50">
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {t("scenarios.duplicateCheck")}
              </p>
              <p
                className={`mt-1 text-sm font-medium ${
                  result.duplicateProduced
                    ? "text-red-600 dark:text-red-400"
                    : "text-emerald-600 dark:text-emerald-400"
                }`}
              >
                {result.duplicateProduced
                  ? t("scenarios.duplicatesDetected")
                  : t("scenarios.noDuplicates")}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* ---------------------------------------------------------------------------
 * Main scenarios page
 * ------------------------------------------------------------------------- */

export const DataPlatformScenarios = () => {
  const t = useTranslations("dataPlatform");
  const router = useNavigate();

  const [results, setResults] = useState<Record<string, ScenarioResult>>({});
  const [runningId, setRunningId] = useState<string | null>(null);
  const [runningAll, setRunningAll] = useState(false);

  const runScenario = async (id: ScenarioId) => {
    setRunningId(id);
    await new Promise((resolve) => setTimeout(resolve, 300));
    const result = scenarioEngine.runScenario(id);
    setResults((prev) => ({ ...prev, [id]: result }));
    setRunningId(null);
  };

  const runAll = async () => {
    setRunningAll(true);
    setResults({});
    for (const def of scenarioEngine.SCENARIO_DEFINITIONS) {
      await new Promise((resolve) => setTimeout(resolve, 200));
      const result = scenarioEngine.runScenario(def.id);
      setResults((prev) => ({ ...prev, [def.id]: result }));
    }
    setRunningAll(false);
  };

  const allResults = scenarioEngine.SCENARIO_DEFINITIONS.map((d) => results[d.id]);
  const passedCount = allResults.filter((r) => r?.passed).length;
  const totalRun = allResults.filter((r) => r).length;

  return (
    <div className="space-y-6 p-4 lg:p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            {t("scenarios.title")}
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            {t("scenarios.description")}
          </p>
        </div>
        <div className="flex items-center gap-3">
          {totalRun > 0 && (
            <span className="text-sm text-gray-600 dark:text-gray-400">
              {passedCount === totalRun
                ? t("scenarios.allPassed")
                : t("scenarios.someFailed", { count: totalRun - passedCount })}
            </span>
          )}
          <button
            onClick={runAll}
            disabled={runningAll}
            className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-blue-700 disabled:opacity-50 dark:bg-blue-500 dark:hover:bg-blue-600"
          >
            {runningAll ? t("scenarios.running") : t("scenarios.runAll")}
          </button>
          <button
            onClick={() => router.push(RouteName.data_platform.path)}
            className="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400"
          >
            {t("nav.dashboard")}
          </button>
        </div>
      </div>

      {/* Scenario cards */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {scenarioEngine.SCENARIO_DEFINITIONS.map((def) => (
          <ScenarioCard
            key={def.id}
            id={def.id}
            label={t(`scenarios.scenarios.${def.id}`)}
            description={def.description}
            requiredBehavior={t(`scenarios.behaviors.${def.id}`)}
            result={results[def.id]}
            isRunning={runningId === def.id || runningAll}
            onRun={() => runScenario(def.id)}
          />
        ))}
      </div>
    </div>
  );
};

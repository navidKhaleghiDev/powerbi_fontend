"use client";

import { useTranslations } from "next-intl";

import {
  useGetCheckpoints,
  useGetIngestionBatches,
  useGetQualityResults,
  useGetSyncRuns,
} from "@/lib/hook/data-platform";
import type {
  BatchStatus,
  Checkpoint,
  IngestionBatch,
  QualityResult,
  RunStatus,
  SyncRun,
} from "@/lib/data-platform";
import { batchStateMachine } from "@/lib/data-platform";
import { useNavigate } from "@/hooks/useNavigate";
import { RouteName } from "@/routes/routesConstants";
import { LoadingSkelton } from "@uiShare/molecules/Loading/LoadingSkeleton";

/* ---------------------------------------------------------------------------
 * Batch status badge
 * ------------------------------------------------------------------------- */

const batchStatusColors: Record<BatchStatus, string> = {
  extracted: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-400",
  uploaded: "bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400",
  verified:
    "bg-indigo-50 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-400",
  applied: "bg-violet-50 text-violet-700 dark:bg-violet-950/40 dark:text-violet-400",
  published:
    "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400",
};

const runStatusColors: Record<RunStatus, string> = {
  pending: "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400",
  running:
    "bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400",
  succeeded:
    "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400",
  failed: "bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400",
  quarantined:
    "bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400",
};

/* ---------------------------------------------------------------------------
 * State machine visualization
 * ------------------------------------------------------------------------- */

const StateMachineBar = ({ batches }: { batches: IngestionBatch[] }) => {
  const t = useTranslations("dataPlatform");

  const counts = batchStateMachine.ORDER.reduce(
    (acc, status) => {
      acc[status] = batches.filter((b) => b.status === status).length;
      return acc;
    },
    {} as Record<BatchStatus, number>,
  );

  return (
    <div className="rounded-2xl border border-gray-200 p-5 dark:border-gray-800">
      <h3 className="mb-4 text-sm font-semibold text-gray-900 dark:text-white">
        {t("ingestion.stateMachine")}
      </h3>
      <div className="flex items-center gap-1 overflow-x-auto">
        {batchStateMachine.ORDER.map((status, idx) => (
          <div key={status} className="flex items-center">
            <div className="flex flex-col items-center">
              <div
                className={`flex size-12 items-center justify-center rounded-full text-xs font-bold ${batchStatusColors[status]}`}
              >
                {counts[status]}
              </div>
              <span className="mt-1 whitespace-nowrap text-xs text-gray-500 dark:text-gray-400">
                {t(`ingestion.statuses.${status}`)}
              </span>
            </div>
            {idx < batchStateMachine.ORDER.length - 1 && (
              <span className="mx-1 text-gray-300 dark:text-gray-700">→</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

/* ---------------------------------------------------------------------------
 * Batch table
 * ------------------------------------------------------------------------- */

interface BatchRowProps {
  batch: IngestionBatch;
  run?: SyncRun;
  checkpoint?: Checkpoint;
  quality?: QualityResult;
}

const BatchRow = ({ batch, run, checkpoint, quality }: BatchRowProps) => {
  const t = useTranslations("dataPlatform");

  return (
    <tr className="border-b border-gray-100 dark:border-gray-800">
      <td className="px-4 py-3 font-mono text-xs text-gray-700 dark:text-gray-300">
        {batch.batchId}
      </td>
      <td className="px-4 py-3">
        <span
          className={`rounded-full px-2 py-1 text-xs font-medium ${batchStatusColors[batch.status]}`}
        >
          {t(`ingestion.statuses.${batch.status}`)}
        </span>
      </td>
      <td className="px-4 py-3 text-gray-600 dark:text-gray-400">
        {batch.rowCount.toLocaleString()}
      </td>
      <td className="px-4 py-3 font-mono text-xs text-gray-600 dark:text-gray-400">
        {batch.sourceCursor}
      </td>
      <td className="px-4 py-3">
        {run ? (
          <span
            className={`rounded-full px-2 py-1 text-xs font-medium ${runStatusColors[run.status]}`}
          >
            {t(`ingestion.runStatuses.${run.status}`)}
          </span>
        ) : (
          <span className="text-xs text-gray-400">—</span>
        )}
      </td>
      <td className="px-4 py-3">
        {quality ? (
          <span
            className={`rounded-full px-2 py-1 text-xs font-medium ${
              quality.verdict === "accept"
                ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400"
                : "bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400"
            }`}
          >
            {quality.verdict}
          </span>
        ) : (
          <span className="text-xs text-gray-400">—</span>
        )}
      </td>
      <td className="px-4 py-3 font-mono text-xs text-gray-600 dark:text-gray-400">
        {checkpoint?.committedCursor ?? "—"}
      </td>
    </tr>
  );
};

/* ---------------------------------------------------------------------------
 * Main ingestion page
 * ------------------------------------------------------------------------- */

export const DataPlatformIngestion = () => {
  const t = useTranslations("dataPlatform");
  const router = useNavigate();

  const { data: batches, isLoading } = useGetIngestionBatches();
  const { data: runs } = useGetSyncRuns();
  const { data: checkpoints } = useGetCheckpoints();
  const { data: quality } = useGetQualityResults();

  return (
    <div className="space-y-6 p-4 lg:p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            {t("ingestion.title")}
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            {t("ingestion.description")}
          </p>
        </div>
        <button
          onClick={() => router.push(RouteName.data_platform.path)}
          className="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400"
        >
          {t("nav.dashboard")}
        </button>
      </div>

      {/* State machine visualization */}
      {!isLoading && batches ? (
        <StateMachineBar batches={batches} />
      ) : (
        <LoadingSkelton isLoading className="h-32" />
      )}

      {/* Batch table */}
      {isLoading || !batches ? (
        <LoadingSkelton isLoading className="h-96" />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-gray-200 dark:border-gray-800">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 dark:bg-gray-800/50">
              <tr>
                <th className="px-4 py-3 text-start font-medium text-gray-600 dark:text-gray-400">
                  {t("ingestion.batchId")}
                </th>
                <th className="px-4 py-3 text-start font-medium text-gray-600 dark:text-gray-400">
                  {t("ingestion.status")}
                </th>
                <th className="px-4 py-3 text-start font-medium text-gray-600 dark:text-gray-400">
                  {t("ingestion.rowCount")}
                </th>
                <th className="px-4 py-3 text-start font-medium text-gray-600 dark:text-gray-400">
                  {t("ingestion.cursor")}
                </th>
                <th className="px-4 py-3 text-start font-medium text-gray-600 dark:text-gray-400">
                  {t("ingestion.runId")}
                </th>
                <th className="px-4 py-3 text-start font-medium text-gray-600 dark:text-gray-400">
                  {t("ingestion.qualityVerdict")}
                </th>
                <th className="px-4 py-3 text-start font-medium text-gray-600 dark:text-gray-400">
                  {t("ingestion.committedCursor")}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {batches.map((batch) => (
                <BatchRow
                  key={batch.batchId}
                  batch={batch}
                  run={runs?.find((r) => r.runId === batch.runId)}
                  checkpoint={checkpoints?.find(
                    (c) =>
                      c.policyId ===
                      runs?.find((r) => r.runId === batch.runId)?.policyId,
                  )}
                  quality={quality?.find((q) => q.batchId === batch.batchId)}
                />
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

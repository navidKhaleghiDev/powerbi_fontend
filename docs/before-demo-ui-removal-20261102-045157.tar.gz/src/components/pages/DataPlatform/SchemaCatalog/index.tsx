"use client";

import { useTranslations } from "next-intl";

import { useGetSchemaVersions } from "@/lib/hook/data-platform";
import { schemaDiscovery } from "@/lib/data-platform";
import type { FieldClassification, SchemaField } from "@/lib/data-platform";
import { useNavigate } from "@/hooks/useNavigate";
import { RouteName } from "@/routes/routesConstants";
import { LoadingSkelton } from "@uiShare/molecules/Loading/LoadingSkeleton";

/* ---------------------------------------------------------------------------
 * Classification badge
 * ------------------------------------------------------------------------- */

const classificationColors: Record<FieldClassification, string> = {
  identifier:
    "bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400",
  pii: "bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400",
  money: "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400",
  timestamp:
    "bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400",
  dimension:
    "bg-violet-50 text-violet-700 dark:bg-violet-950/40 dark:text-violet-400",
  measure: "bg-teal-50 text-teal-700 dark:bg-teal-950/40 dark:text-teal-400",
  reference:
    "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-400",
  unknown:
    "bg-gray-50 text-gray-500 dark:bg-gray-900 dark:text-gray-500",
};

/* ---------------------------------------------------------------------------
 * Discovery phase pipeline visualization
 * ------------------------------------------------------------------------- */

const DiscoveryPipeline = () => {
  const t = useTranslations("dataPlatform");

  return (
    <div className="flex items-center gap-1 overflow-x-auto rounded-2xl border border-gray-200 p-5 dark:border-gray-800">
      {schemaDiscovery.PHASE_ORDER.map((phase, idx) => (
        <div key={phase} className="flex items-center">
          <div className="flex flex-col items-center">
            <div className="flex size-10 items-center justify-center rounded-full bg-blue-50 text-sm font-medium text-blue-600 dark:bg-blue-950/40 dark:text-blue-400">
              {idx + 1}
            </div>
            <span className="mt-1 whitespace-nowrap text-xs text-gray-600 dark:text-gray-400">
              {t(`schema.discoveryPhases.${phase}`)}
            </span>
          </div>
          {idx < schemaDiscovery.PHASE_ORDER.length - 1 && (
            <span className="mx-1 text-gray-300 dark:text-gray-700">→</span>
          )}
        </div>
      ))}
    </div>
  );
};

/* ---------------------------------------------------------------------------
 * Schema field row
 * ------------------------------------------------------------------------- */

interface FieldRowProps {
  field: SchemaField;
}

const FieldRow = ({ field }: FieldRowProps) => {
  const t = useTranslations("dataPlatform");

  return (
    <tr className="border-b border-gray-100 dark:border-gray-800">
      <td className="px-4 py-2 font-mono text-sm text-gray-900 dark:text-gray-200">
        {field.name}
      </td>
      <td className="px-4 py-2 font-mono text-xs text-gray-600 dark:text-gray-400">
        {field.sourceType}
      </td>
      <td className="px-4 py-2 text-center">
        {field.nullable ? (
          <span className="text-xs text-amber-600 dark:text-amber-400">
            NULL
          </span>
        ) : (
          <span className="text-xs text-gray-400">NOT NULL</span>
        )}
      </td>
      <td className="px-4 py-2">
        <span
          className={`rounded-full px-2 py-1 text-xs font-medium ${classificationColors[field.classification]}`}
        >
          {t(`schema.classifications.${field.classification}`)}
        </span>
      </td>
      <td className="px-4 py-2 text-center">
        {field.pii ? (
          <span className="text-xs font-medium text-red-600 dark:text-red-400">
            PII
          </span>
        ) : (
          <span className="text-xs text-gray-400">—</span>
        )}
      </td>
    </tr>
  );
};

/* ---------------------------------------------------------------------------
 * Schema version card
 * ------------------------------------------------------------------------- */

interface SchemaCardProps {
  version: { versionId: string; datasetId: string; fingerprint: string; fields: SchemaField[] };
}

const SchemaCard = ({ version }: SchemaCardProps) => {
  const t = useTranslations("dataPlatform");

  return (
    <div className="overflow-hidden rounded-2xl border border-gray-200 dark:border-gray-800">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-200 bg-gray-50 px-4 py-3 dark:border-gray-800 dark:bg-gray-800/50">
        <div>
          <p className="font-mono text-sm font-medium text-gray-900 dark:text-white">
            {version.datasetId}
          </p>
          <p className="font-mono text-xs text-gray-500 dark:text-gray-400">
            {version.fingerprint}
          </p>
        </div>
        <span className="rounded-full bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 dark:bg-blue-950/40 dark:text-blue-400">
          {version.fields.length} {t("schema.fieldName").toLowerCase()}s
        </span>
      </div>

      {/* Fields table */}
      <table className="w-full">
        <thead className="bg-gray-50/50 dark:bg-gray-800/30">
          <tr>
            <th className="px-4 py-2 text-start text-xs font-medium text-gray-500 dark:text-gray-400">
              {t("schema.fieldName")}
            </th>
            <th className="px-4 py-2 text-start text-xs font-medium text-gray-500 dark:text-gray-400">
              {t("schema.sourceType")}
            </th>
            <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 dark:text-gray-400">
              {t("schema.nullable")}
            </th>
            <th className="px-4 py-2 text-start text-xs font-medium text-gray-500 dark:text-gray-400">
              {t("schema.classification")}
            </th>
            <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 dark:text-gray-400">
              {t("schema.pii")}
            </th>
          </tr>
        </thead>
        <tbody>
          {version.fields.map((field) => (
            <FieldRow key={field.name} field={field} />
          ))}
        </tbody>
      </table>
    </div>
  );
};

/* ---------------------------------------------------------------------------
 * Main schema catalog page
 * ------------------------------------------------------------------------- */

export const DataPlatformSchema = () => {
  const t = useTranslations("dataPlatform");
  const router = useNavigate();

  const { data: versions, isLoading } = useGetSchemaVersions();

  return (
    <div className="space-y-6 p-4 lg:p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            {t("schema.title")}
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            {t("schema.description")}
          </p>
        </div>
        <button
          onClick={() => router.push(RouteName.data_platform.path)}
          className="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400"
        >
          {t("nav.dashboard")}
        </button>
      </div>

      {/* Discovery pipeline */}
      <DiscoveryPipeline />

      {/* Schema version cards */}
      {isLoading || !versions ? (
        <div className="space-y-4">
          <LoadingSkelton isLoading className="h-64" />
          <LoadingSkelton isLoading className="h-64" />
        </div>
      ) : (
        <div className="space-y-4">
          {versions.map((version) => (
            <SchemaCard key={version.versionId} version={version} />
          ))}
        </div>
      )}
    </div>
  );
};

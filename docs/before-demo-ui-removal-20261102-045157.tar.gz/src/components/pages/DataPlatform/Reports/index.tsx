"use client";

import { useMemo } from "react";

import { useTranslations } from "next-intl";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { batchStateMachine } from "@/lib/data-platform";
import { useGetIngestionBatches } from "@/lib/hook/data-platform";
import type { BatchStatus } from "@/lib/data-platform";
import { LoadingSkelton } from "@uiShare/molecules/Loading/LoadingSkeleton";

/* ---------------------------------------------------------------------------
 * Mock time-series data for charts
 * ------------------------------------------------------------------------- */

const generateThroughputData = () => {
  const hours = 24;
  return Array.from({ length: hours }, (_, i) => {
    const baseThroughput = 850;
    const variance = Math.sin((i / hours) * Math.PI * 2) * 200;
    const noise = Math.random() * 100;
    return {
      hour: `${i}:00`,
      throughput: Math.round(baseThroughput + variance + noise),
    };
  });
};

const generateErrorRateData = () => {
  const hours = 24;
  return Array.from({ length: hours }, (_, i) => {
    const baseError = 0.02;
    const spike = i === 14 || i === 15 ? 0.08 : 0;
    const noise = Math.random() * 0.01;
    return {
      hour: `${i}:00`,
      errorRate: parseFloat(((baseError + spike + noise) * 100).toFixed(2)),
    };
  });
};

/* ---------------------------------------------------------------------------
 * Batch status distribution pie chart
 * ------------------------------------------------------------------------- */

const statusColors: Record<BatchStatus, string> = {
  extracted: "#9ca3af",
  uploaded: "#3b82f6",
  verified: "#6366f1",
  applied: "#8b5cf6",
  published: "#10b981",
};

const BatchStatusChart = () => {
  const t = useTranslations("dataPlatform");
  const { data: batches, isLoading } = useGetIngestionBatches();

  const chartData = useMemo(() => {
    if (!batches) return [];
    return batchStateMachine.ORDER.map((status) => ({
      name: t(`ingestion.statuses.${status}`),
      value: batches.filter((b) => b.status === status).length,
      status,
    })).filter((d) => d.value > 0);
  }, [batches, t]);

  if (isLoading || !batches) {
    return <LoadingSkelton isLoading className="h-64" />;
  }

  return (
    <div className="rounded-2xl border border-gray-200 p-5 dark:border-gray-800">
      <h3 className="mb-4 text-sm font-semibold text-gray-900 dark:text-white">
        {t("reports.batchStatusDistribution")}
      </h3>
      <ResponsiveContainer width="100%" height={250}>
        <PieChart>
          <Pie
            data={chartData}
            dataKey="value"
            nameKey="name"
            cx="50%"
            cy="50%"
            outerRadius={80}
            innerRadius={40}
            paddingAngle={2}
          >
            {chartData.map((entry) => (
              <Cell
                key={entry.status}
                fill={statusColors[entry.status as BatchStatus]}
              />
            ))}
          </Pie>
          <Tooltip
            contentStyle={{
              borderRadius: "0.75rem",
              border: "1px solid #e5e7eb",
            }}
          />
          <Legend wrapperStyle={{ fontSize: "0.75rem" }} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

/* ---------------------------------------------------------------------------
 * Throughput trend line chart
 * ------------------------------------------------------------------------- */

const ThroughputChart = () => {
  const t = useTranslations("dataPlatform");
  const data = useMemo(() => generateThroughputData(), []);

  return (
    <div className="rounded-2xl border border-gray-200 p-5 dark:border-gray-800">
      <div className="mb-2 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-gray-900 dark:text-white">
          {t("reports.throughputTrend")}
        </h3>
        <span className="text-xs text-gray-500 dark:text-gray-400">
          {t("reports.last24h")}
        </span>
      </div>
      <ResponsiveContainer width="100%" height={250}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.2} />
          <XAxis
            dataKey="hour"
            tick={{ fontSize: 10 }}
            interval={3}
            stroke="#6b7280"
          />
          <YAxis tick={{ fontSize: 10 }} stroke="#6b7280" />
          <Tooltip
            contentStyle={{
              borderRadius: "0.75rem",
              border: "1px solid #e5e7eb",
            }}
          />
          <Line
            type="monotone"
            dataKey="throughput"
            stroke="#3b82f6"
            strokeWidth={2}
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

/* ---------------------------------------------------------------------------
 * Error rate trend area chart
 * ------------------------------------------------------------------------- */

const ErrorRateChart = () => {
  const t = useTranslations("dataPlatform");
  const data = useMemo(() => generateErrorRateData(), []);

  return (
    <div className="rounded-2xl border border-gray-200 p-5 dark:border-gray-800">
      <div className="mb-2 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-gray-900 dark:text-white">
          {t("reports.errorRateTrend")}
        </h3>
        <span className="text-xs text-gray-500 dark:text-gray-400">
          {t("reports.last24h")}
        </span>
      </div>
      <ResponsiveContainer width="100%" height={250}>
        <AreaChart data={data}>
          <defs>
            <linearGradient id="errorGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.2} />
          <XAxis
            dataKey="hour"
            tick={{ fontSize: 10 }}
            interval={3}
            stroke="#6b7280"
          />
          <YAxis tick={{ fontSize: 10 }} stroke="#6b7280" />
          <Tooltip
            contentStyle={{
              borderRadius: "0.75rem",
              border: "1px solid #e5e7eb",
            }}
            formatter={(value) => [`${value}%`, "Error Rate"]}
          />
          <Area
            type="monotone"
            dataKey="errorRate"
            stroke="#ef4444"
            strokeWidth={2}
            fill="url(#errorGradient)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};

/* ---------------------------------------------------------------------------
 * Reports section (used on the dashboard)
 * ------------------------------------------------------------------------- */

export const DataPlatformReports = () => {
  const t = useTranslations("dataPlatform");

  return (
    <section className="space-y-4">
      <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
        {t("reports.title")}
      </h2>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <ThroughputChart />
        <BatchStatusChart />
      </div>
      <div className="grid grid-cols-1 gap-4">
        <ErrorRateChart />
      </div>
    </section>
  );
};

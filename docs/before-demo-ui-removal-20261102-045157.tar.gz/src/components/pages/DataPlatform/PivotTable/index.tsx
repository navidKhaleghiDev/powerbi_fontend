"use client";

import { useMemo, useState } from "react";

import { useTranslations } from "next-intl";
import {
  DndContext,
  type DragEndEvent,
  KeyboardSensor,
  PointerSensor,
  useDraggable,
  useDroppable,
  useSensor,
  useSensors,
} from "@dnd-kit/core";

import { useGetWarehouseRecords } from "@/lib/hook/data-platform";
import type { WarehouseRecord } from "@/lib/data-platform";
import { LoadingSkelton } from "@uiShare/molecules/Loading/LoadingSkeleton";

/* ---------------------------------------------------------------------------
 * Types
 * ------------------------------------------------------------------------- */

type Zone = "available" | "rows" | "columns" | "values";

interface FieldItem {
  name: string;
  zone: Zone;
}

type Aggregation = "sum" | "count" | "avg";

/* ---------------------------------------------------------------------------
 * Pivot engine — pure function that builds the pivot grid from raw records
 * ------------------------------------------------------------------------- */

interface PivotResult {
  rowKeys: string[];
  columnKeys: string[];
  cells: Map<string, number>;
}

const aggregate = (
  values: number[],
  agg: Aggregation,
): number => {
  if (agg === "count") return values.length;
  if (agg === "sum") return values.reduce((a, b) => a + b, 0);
  if (agg === "avg")
    return values.length > 0
      ? values.reduce((a, b) => a + b, 0) / values.length
      : 0;
  return 0;
};

const buildPivot = (
  records: WarehouseRecord[],
  rowFields: string[],
  columnFields: string[],
  valueFields: string[],
  agg: Aggregation,
): PivotResult => {
  const rowKeys = new Set<string>();
  const columnKeys = new Set<string>();
  const cells = new Map<string, number>();
  const valueField = valueFields[0];

  // Collect raw values per cell
  const cellValues = new Map<string, number[]>();

  for (const record of records) {
    const rowKey = rowFields.map((f) => String(record.data[f] ?? "—")).join(" / ");
    const colKey = columnFields.map((f) => String(record.data[f] ?? "—")).join(" / ");

    rowKeys.add(rowKey);
    columnKeys.add(colKey);

    const cellKey = `${rowKey}|||${colKey}`;
    const numericValue = valueField
      ? Number(record.data[valueField] ?? 0) || 0
      : 1;

    const existing = cellValues.get(cellKey);
    if (existing) {
      existing.push(numericValue);
    } else {
      cellValues.set(cellKey, [numericValue]);
    }
  }

  // Aggregate
  for (const [key, vals] of cellValues) {
    cells.set(key, aggregate(vals, agg));
  }

  return {
    rowKeys: [...rowKeys].sort(),
    columnKeys: [...columnKeys].sort(),
    cells,
  };
};

/* ---------------------------------------------------------------------------
 * CSV export
 * ------------------------------------------------------------------------- */

const exportToCsv = (
  pivot: PivotResult,
  rowFields: string[],
  valueFields: string[],
): void => {
  const headers = [...rowFields, ...pivot.columnKeys];
  const rows = pivot.rowKeys.map((rowKey) => {
    const rowData = rowKey.split(" / ");
    const values = pivot.columnKeys.map((colKey) => {
      const cellKey = `${rowKey}|||${colKey}`;
      return String(pivot.cells.get(cellKey) ?? 0);
    });
    return [...rowData, ...values];
  });

  const csv = [
    headers.map((h) => `"${h}"`).join(","),
    ...rows.map((r) => r.map((c) => `"${c}"`).join(",")),
  ].join("\n");

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "pivot_export.csv";
  link.click();
  URL.revokeObjectURL(url);
};

/* ---------------------------------------------------------------------------
 * Draggable field chip
 * ------------------------------------------------------------------------- */

interface FieldChipProps {
  field: FieldItem;
}

const FieldChip = ({ field }: FieldChipProps) => {
  const { attributes, listeners, setNodeRef, transform, isDragging } =
    useDraggable({ id: `field-${field.name}` });

  const style = transform
    ? { transform: `translate3d(${transform.x}px, ${transform.y}px, 0)` }
    : undefined;

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className={`cursor-grab rounded-lg border px-3 py-1.5 text-sm font-medium transition-all ${
        isDragging
          ? "border-blue-400 bg-blue-50 opacity-50 dark:bg-blue-950/40"
          : "border-gray-200 bg-white hover:border-blue-300 dark:border-gray-700 dark:bg-gray-800 dark:hover:border-blue-700"
      }`}
    >
      {field.name}
    </div>
  );
};

/* ---------------------------------------------------------------------------
 * Drop zone
 * ------------------------------------------------------------------------- */

interface DropZoneProps {
  id: Zone;
  label: string;
  fields: FieldItem[];
  accentColor: string;
}

const DropZone = ({ id, label, fields, accentColor }: DropZoneProps) => {
  const { isOver, setNodeRef } = useDroppable({ id });
  const t = useTranslations("dataPlatform");

  return (
    <div
      ref={setNodeRef}
      className={`min-h-[80px] rounded-xl border-2 border-dashed p-3 transition-colors ${
        isOver
          ? "border-blue-400 bg-blue-50 dark:bg-blue-950/30"
          : "border-gray-200 dark:border-gray-700"
      }`}
    >
      <p className={`mb-2 text-xs font-semibold ${accentColor}`}>{label}</p>
      <div className="flex flex-wrap gap-2">
        {fields.length === 0 ? (
          <span className="text-xs text-gray-400">
            {t("pivot.dropHere")}
          </span>
        ) : (
          fields.map((field) => (
            <FieldChip key={field.name} field={field} />
          ))
        )}
      </div>
    </div>
  );
};

/* ---------------------------------------------------------------------------
 * Main pivot table component
 * ------------------------------------------------------------------------- */

export const PivotTable = () => {
  const t = useTranslations("dataPlatform");
  const { data: records, isLoading } = useGetWarehouseRecords();

  // Extract available fields from the data
  const availableFieldNames = useMemo(() => {
    if (!records || records.length === 0) return [];
    const firstRecord = records[0];
    return Object.keys(firstRecord.data);
  }, [records]);

  // State: which fields are in which zone
  const [fieldZones, setFieldZones] = useState<Record<string, Zone>>({});
  const [aggregation, setAggregation] = useState<Aggregation>("sum");

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor),
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over) return;

    const fieldName = String(active.id).replace("field-", "");
    const targetZone = over.id as Zone;

    setFieldZones((prev) => ({ ...prev, [fieldName]: targetZone }));
  };

  // Partition fields by zone
  const getFieldsForZone = (zone: Zone): FieldItem[] =>
    availableFieldNames
      .filter((name) => (fieldZones[name] ?? "available") === zone)
      .map((name) => ({ name, zone }));

  const rowFields = getFieldsForZone("rows").map((f) => f.name);
  const columnFields = getFieldsForZone("columns").map((f) => f.name);
  const valueFields = getFieldsForZone("values").map((f) => f.name);

  // Build the pivot
  const pivot = useMemo(() => {
    if (!records || rowFields.length === 0 || valueFields.length === 0) {
      return null;
    }
    return buildPivot(records, rowFields, columnFields, valueFields, aggregation);
  }, [records, rowFields, columnFields, valueFields, aggregation]);

  if (isLoading || !records) {
    return <LoadingSkelton isLoading className="h-96" />;
  }

  return (
    <DndContext sensors={sensors} onDragEnd={handleDragEnd}>
      <div className="space-y-4">
        {/* Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-gray-200 p-3 dark:border-gray-800">
          <div className="flex items-center gap-2">
            <label className="text-sm text-gray-600 dark:text-gray-400">
              {t("pivot.aggregation")}:
            </label>
            <select
              value={aggregation}
              onChange={(e) => setAggregation(e.target.value as Aggregation)}
              className="rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-sm dark:border-gray-700 dark:bg-gray-800 dark:text-white"
            >
              <option value="sum">{t("pivot.sum")}</option>
              <option value="count">{t("pivot.count")}</option>
              <option value="avg">{t("pivot.average")}</option>
            </select>
          </div>
          <button
            onClick={() => pivot && exportToCsv(pivot, rowFields, valueFields)}
            disabled={!pivot}
            className="rounded-lg bg-emerald-600 px-4 py-1.5 text-sm font-medium text-white transition-colors hover:bg-emerald-700 disabled:opacity-50 dark:bg-emerald-500 dark:hover:bg-emerald-600"
          >
            {t("pivot.exportCsv")}
          </button>
        </div>

        {/* Drop zones grid */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <DropZone
            id="available"
            label={t("pivot.fields")}
            fields={getFieldsForZone("available")}
            accentColor="text-gray-600 dark:text-gray-400"
          />
          <DropZone
            id="rows"
            label={t("pivot.rows")}
            fields={getFieldsForZone("rows")}
            accentColor="text-blue-600 dark:text-blue-400"
          />
          <DropZone
            id="columns"
            label={t("pivot.columns")}
            fields={getFieldsForZone("columns")}
            accentColor="text-violet-600 dark:text-violet-400"
          />
          <DropZone
            id="values"
            label={t("pivot.values")}
            fields={getFieldsForZone("values")}
            accentColor="text-emerald-600 dark:text-emerald-400"
          />
        </div>

        {/* Pivot grid */}
        {pivot ? (
          <div className="overflow-x-auto rounded-2xl border border-gray-200 dark:border-gray-800">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 dark:bg-gray-800/50">
                <tr>
                  {[...rowFields, ...columnFields].map((header, idx) => (
                    <th
                      key={idx}
                      className="border-b border-gray-200 px-4 py-3 text-start font-medium text-gray-600 dark:border-gray-700 dark:text-gray-400"
                    >
                      {header}
                    </th>
                  ))}
                </tr>
                <tr className="bg-gray-50/50 dark:bg-gray-800/30">
                  {rowFields.map((_, idx) => (
                    <th
                      key={`rowh-${idx}`}
                      className="border-b border-gray-200 px-4 py-2 text-xs text-gray-400 dark:border-gray-700"
                    >
                      {t("pivot.rows")}
                    </th>
                  ))}
                  {pivot.columnKeys.map((colKey) => (
                    <th
                      key={colKey}
                      className="border-b border-gray-200 px-4 py-2 text-start text-xs font-medium text-gray-700 dark:border-gray-700 dark:text-gray-300"
                    >
                      {colKey}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {pivot.rowKeys.map((rowKey) => (
                  <tr key={rowKey}>
                    {rowKey.split(" / ").map((cell, idx) => (
                      <td
                        key={idx}
                        className="px-4 py-2 text-start font-medium text-gray-900 dark:text-gray-200"
                      >
                        {cell}
                      </td>
                    ))}
                    {pivot.columnKeys.map((colKey) => {
                      const cellKey = `${rowKey}|||${colKey}`;
                      const value = pivot.cells.get(cellKey) ?? 0;
                      return (
                        <td
                          key={colKey}
                          className="px-4 py-2 text-start text-gray-700 dark:text-gray-300"
                        >
                          {value.toLocaleString()}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-gray-200 p-12 text-center dark:border-gray-700">
            <p className="text-sm text-gray-400">
              {t("pivot.dragHint")}
            </p>
          </div>
        )}
      </div>
    </DndContext>
  );
};

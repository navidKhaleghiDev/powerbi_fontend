"use client";

import { useTranslations } from "next-intl";

import { useNavigate } from "@/hooks/useNavigate";
import { RouteName } from "@/routes/routesConstants";

/* ---------------------------------------------------------------------------
 * Security feature card
 * ------------------------------------------------------------------------- */

interface FeatureCardProps {
  title: string;
  description: string;
  statusKey: string;
}

const FeatureCard = ({ title, description, statusKey }: FeatureCardProps) => {
  const t = useTranslations("dataPlatform");
  const enabled = statusKey === "enabled";

  return (
    <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-gray-900">
      <div className="flex items-start justify-between">
        <h3 className="text-base font-semibold text-gray-900 dark:text-white">
          {title}
        </h3>
        <span
          className={`rounded-full px-3 py-1 text-xs font-medium ${
            enabled
              ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400"
              : "bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400"
          }`}
        >
          {t(`security.${statusKey}`)}
        </span>
      </div>
      <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
        {description}
      </p>
    </div>
  );
};

/* ---------------------------------------------------------------------------
 * Main security page
 * ------------------------------------------------------------------------- */

export const SecurityPage = () => {
  const t = useTranslations("dataPlatform");
  const router = useNavigate();

  const mfaMethods = [
    { key: "totp", status: "enabled" as const },
    { key: "passkey", status: "enabled" as const },
    { key: "otpEmail", status: "disabled" as const },
    { key: "otpSms", status: "disabled" as const },
  ];

  const securityFeatures = [
    { key: "riskScoring", status: "enabled" as const },
    { key: "bruteForce", status: "enabled" as const },
    { key: "deviceTrust", status: "enabled" as const },
    { key: "auditLog", status: "enabled" as const },
  ];

  return (
    <div className="space-y-6 p-4 lg:p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            {t("security.title")}
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            {t("security.description")}
          </p>
        </div>
        <button
          onClick={() => router.push(RouteName.data_platform.path)}
          className="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400"
        >
          {t("nav.dashboard")}
        </button>
      </div>

      {/* MFA methods */}
      <section>
        <h2 className="mb-3 text-lg font-semibold text-gray-900 dark:text-white">
          {t("security.mfa")}
        </h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {mfaMethods.map((method) => (
            <FeatureCard
              key={method.key}
              title={t(`security.${method.key}`)}
              description={t("security.description")}
              statusKey={method.status}
            />
          ))}
        </div>
      </section>

      {/* Security controls */}
      <section>
        <h2 className="mb-3 text-lg font-semibold text-gray-900 dark:text-white">
          {t("security.riskScoring")}
        </h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {securityFeatures.map((feature) => (
            <FeatureCard
              key={feature.key}
              title={t(`security.${feature.key}`)}
              description={t("security.description")}
              statusKey={feature.status}
            />
          ))}
        </div>
      </section>
    </div>
  );
};

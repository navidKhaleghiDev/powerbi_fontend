"use client";

import { useTranslations } from "next-intl";

import { useNavigate } from "@/hooks/useNavigate";
import { RouteName } from "@/routes/routesConstants";

/* ---------------------------------------------------------------------------
 * Mock report version data
 * ------------------------------------------------------------------------- */

interface ReportVersion {
  version: string;
  uploadedBy: string;
  uploadedAt: string;
  fileSize: string;
}

const mockVersions: ReportVersion[] = [
  { version: "v3.2", uploadedBy: "admin", uploadedAt: "2026-10-28 14:30", fileSize: "4.2 MB" },
  { version: "v3.1", uploadedBy: "ahmadi", uploadedAt: "2026-10-15 09:15", fileSize: "4.1 MB" },
  { version: "v3.0", uploadedBy: "admin", uploadedAt: "2026-10-01 16:00", fileSize: "4.0 MB" },
  { version: "v2.9", uploadedBy: "rezaii", uploadedAt: "2026-09-20 11:45", fileSize: "3.8 MB" },
];

const mockTopReports = [
  { name: "Sales Pipeline Dashboard", views: 1240 },
  { name: "Monthly Finance Report", views: 980 },
  { name: "Customer Analysis", views: 720 },
  { name: "Inventory Status", views: 540 },
];

const mockActiveUsers = [
  { name: "Mohammad Ahmadi", views: 340 },
  { name: "Ali Rezaei", views: 280 },
  { name: "Sara Karimi", views: 190 },
  { name: "Hossein Norouzi", views: 120 },
];

/* ---------------------------------------------------------------------------
 * Main report management page
 * ------------------------------------------------------------------------- */

export const ReportManagementPage = () => {
  const t = useTranslations("dataPlatform");
  const router = useNavigate();

  return (
    <div className="space-y-6 p-4 lg:p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            {t("reportManagement.title")}
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            {t("reportManagement.description")}
          </p>
        </div>
        <button
          onClick={() => router.push(RouteName.data_platform.path)}
          className="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400"
        >
          {t("nav.dashboard")}
        </button>
      </div>

      {/* Version history */}
      <section>
        <h2 className="mb-3 text-lg font-semibold text-gray-900 dark:text-white">
          {t("reportManagement.versionHistory")}
        </h2>
        <div className="overflow-x-auto rounded-2xl border border-gray-200 dark:border-gray-800">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 dark:bg-gray-800/50">
              <tr>
                <th className="px-4 py-3 text-start font-medium text-gray-600 dark:text-gray-400">
                  {t("reportManagement.versionHistory")}
                </th>
                <th className="px-4 py-3 text-start font-medium text-gray-600 dark:text-gray-400">
                  {t("reportManagement.uploadedBy")}
                </th>
                <th className="px-4 py-3 text-start font-medium text-gray-600 dark:text-gray-400">
                  {t("reportManagement.uploadedAt")}
                </th>
                <th className="px-4 py-3 text-start font-medium text-gray-600 dark:text-gray-400">
                  {t("reportManagement.fileSize")}
                </th>
                <th className="px-4 py-3 text-center font-medium text-gray-600 dark:text-gray-400">
                  {t("reportManagement.download")}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {mockVersions.map((ver) => (
                <tr key={ver.version}>
                  <td className="px-4 py-3 font-mono text-xs font-medium text-gray-900 dark:text-gray-200">
                    {ver.version}
                  </td>
                  <td className="px-4 py-3 text-gray-600 dark:text-gray-400">
                    {ver.uploadedBy}
                  </td>
                  <td className="px-4 py-3 text-gray-600 dark:text-gray-400">
                    {ver.uploadedAt}
                  </td>
                  <td className="px-4 py-3 text-gray-600 dark:text-gray-400">
                    {ver.fileSize}
                  </td>
                  <td className="px-4 py-3 text-center">
                    <button className="rounded-lg bg-blue-50 px-3 py-1 text-xs font-medium text-blue-700 hover:bg-blue-100 dark:bg-blue-950/40 dark:text-blue-400">
                      {t("reportManagement.download")}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* View statistics */}
      <section>
        <h2 className="mb-3 text-lg font-semibold text-gray-900 dark:text-white">
          {t("reportManagement.viewStatistics")}
        </h2>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {/* Top reports */}
          <div className="rounded-2xl border border-gray-200 p-5 dark:border-gray-800">
            <h3 className="mb-3 text-sm font-semibold text-gray-900 dark:text-white">
              {t("reportManagement.topReports")}
            </h3>
            <div className="space-y-2">
              {mockTopReports.map((report, idx) => {
                const maxViews = mockTopReports[0].views;
                const percentage = (report.views / maxViews) * 100;
                return (
                  <div key={report.name} className="flex items-center gap-3">
                    <span className="w-6 shrink-0 text-xs text-gray-400">
                      {idx + 1}
                    </span>
                    <span className="w-40 shrink-0 truncate text-sm text-gray-700 dark:text-gray-300">
                      {report.name}
                    </span>
                    <div className="h-6 flex-1 overflow-hidden rounded-lg bg-gray-100 dark:bg-gray-800">
                      <div
                        className="flex h-full items-center justify-end rounded-lg bg-gradient-to-l from-blue-500 to-indigo-500 px-2 text-xs font-medium text-white"
                        style={{ width: `${Math.max(percentage, 10)}%` }}
                      >
                        {report.views}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Active users */}
          <div className="rounded-2xl border border-gray-200 p-5 dark:border-gray-800">
            <h3 className="mb-3 text-sm font-semibold text-gray-900 dark:text-white">
              {t("reportManagement.activeUsers")}
            </h3>
            <div className="space-y-2">
              {mockActiveUsers.map((user, idx) => {
                const maxViews = mockActiveUsers[0].views;
                const percentage = (user.views / maxViews) * 100;
                return (
                  <div key={user.name} className="flex items-center gap-3">
                    <span className="w-6 shrink-0 text-xs text-gray-400">
                      {idx + 1}
                    </span>
                    <span className="w-40 shrink-0 truncate text-sm text-gray-700 dark:text-gray-300">
                      {user.name}
                    </span>
                    <div className="h-6 flex-1 overflow-hidden rounded-lg bg-gray-100 dark:bg-gray-800">
                      <div
                        className="flex h-full items-center justify-end rounded-lg bg-gradient-to-l from-emerald-500 to-teal-500 px-2 text-xs font-medium text-white"
                        style={{ width: `${Math.max(percentage, 10)}%` }}
                      >
                        {user.views}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Scheduled subscriptions */}
      <section>
        <h2 className="mb-3 text-lg font-semibold text-gray-900 dark:text-white">
          {t("reportManagement.subscriptions")}
        </h2>
        <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-gray-900">
          <div className="flex flex-wrap gap-3">
            {(["daily", "weekly", "monthly"] as const).map((freq) => (
              <button
                key={freq}
                className="rounded-xl border border-gray-200 px-4 py-2 text-sm font-medium text-gray-700 transition-colors hover:border-blue-300 hover:bg-blue-50 dark:border-gray-700 dark:text-gray-300 dark:hover:border-blue-700 dark:hover:bg-blue-950/30"
              >
                {t(`reportManagement.${freq}`)}
              </button>
            ))}
          </div>
          <p className="mt-4 rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-700 dark:bg-amber-950/20 dark:text-amber-400">
            {t("reportManagement.rlsNote")}
          </p>
        </div>
      </section>
    </div>
  );
};

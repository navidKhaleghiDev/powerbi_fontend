export const RouteName = {
  data_platform: {
    path: "/data-platform",
    slug: "data-platform",
  },
  data_platform_sources: {
    path: "/data-platform/sources",
    slug: "sources",
  },
  data_platform_ingestion: {
    path: "/data-platform/ingestion",
    slug: "ingestion",
  },
  data_platform_schema: {
    path: "/data-platform/schema",
    slug: "schema",
  },
  data_platform_scenarios: {
    path: "/data-platform/scenarios",
    slug: "scenarios",
  },
  data_platform_pivot: {
    path: "/data-platform/pivot",
    slug: "pivot",
  },
  data_platform_security: {
    path: "/data-platform/security",
    slug: "security",
  },
  data_platform_reports: {
    path: "/data-platform/reports",
    slug: "reports",
  },
} as const;

import { Suspense } from "react";

import { ReportManagementPage } from "@/components/pages/DataPlatform/ReportManagement";
import { Skeleton } from "@uiShare/molecules/Loading/LoadingSkeleton";

export default function DataPlatformReportsPage() {
  return (
    <Suspense fallback={<Skeleton className="h-64" />}>
      <ReportManagementPage />
    </Suspense>
  );
}

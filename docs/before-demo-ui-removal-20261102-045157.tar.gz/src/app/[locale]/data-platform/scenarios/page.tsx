import { Suspense } from "react";

import { DataPlatformScenarios } from "@/components/pages/DataPlatform/Scenarios";
import { Skeleton } from "@uiShare/molecules/Loading/LoadingSkeleton";

export default function DataPlatformScenariosPage() {
  return (
    <Suspense fallback={<Skeleton className="h-64" />}>
      <DataPlatformScenarios />
    </Suspense>
  );
}

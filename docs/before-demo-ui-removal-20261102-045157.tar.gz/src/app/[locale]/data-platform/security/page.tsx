import { Suspense } from "react";

import { SecurityPage } from "@/components/pages/DataPlatform/Security";
import { Skeleton } from "@uiShare/molecules/Loading/LoadingSkeleton";

export default function DataPlatformSecurityPage() {
  return (
    <Suspense fallback={<Skeleton className="h-64" />}>
      <SecurityPage />
    </Suspense>
  );
}

import { Suspense } from "react";

import { PivotTable } from "@/components/pages/DataPlatform/PivotTable";
import { Skeleton } from "@uiShare/molecules/Loading/LoadingSkeleton";

export default function DataPlatformPivotPage() {
  return (
    <Suspense fallback={<Skeleton className="h-64" />}>
      <PivotTable />
    </Suspense>
  );
}

import { Suspense } from "react";

import { DataPlatformSchema } from "@/components/pages/DataPlatform/SchemaCatalog";
import { Skeleton } from "@uiShare/molecules/Loading/LoadingSkeleton";

export default function DataPlatformSchemaPage() {
  return (
    <Suspense fallback={<Skeleton className="h-64" />}>
      <DataPlatformSchema />
    </Suspense>
  );
}

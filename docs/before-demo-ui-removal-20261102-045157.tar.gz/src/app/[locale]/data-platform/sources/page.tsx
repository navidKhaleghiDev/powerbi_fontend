import { Suspense } from "react";

import { DataPlatformSources } from "@/components/pages/DataPlatform/Sources";
import { Skeleton } from "@uiShare/molecules/Loading/LoadingSkeleton";

export default function DataPlatformSourcesPage() {
  return (
    <Suspense fallback={<Skeleton className="h-64" />}>
      <DataPlatformSources />
    </Suspense>
  );
}

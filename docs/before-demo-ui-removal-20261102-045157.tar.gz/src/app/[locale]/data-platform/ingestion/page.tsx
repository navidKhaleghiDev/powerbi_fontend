import { Suspense } from "react";

import { DataPlatformIngestion } from "@/components/pages/DataPlatform/Ingestion";
import { Skeleton } from "@uiShare/molecules/Loading/LoadingSkeleton";

export default function DataPlatformIngestionPage() {
  return (
    <Suspense fallback={<Skeleton className="h-64" />}>
      <DataPlatformIngestion />
    </Suspense>
  );
}
